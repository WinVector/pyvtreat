
Advanced data pre-processor/conditioner for supervised machine learning

Derived from https://github.com/WinVector/vtreat



