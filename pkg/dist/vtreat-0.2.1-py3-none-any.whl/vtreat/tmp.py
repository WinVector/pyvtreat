plan = [
            {
                "train": [i for i in range(n_rows) if data['i'][i]>ov],
                "app": [i for i in range(n_rows) if data['i'][i]==ov],
            }
            for ov in ov_left
        ] + [
            {
                "train": [i for i in range(n_rows) if data['i'][i]<ov],
                "app": [i for i in range(n_rows) if data['i'][i]==ov],
            }
            for ov in ov_right
        ]