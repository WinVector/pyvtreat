
Compare to [R solution](https://github.com/WinVector/PDSwR2/blob/master/KDD2009/KDD2009vtreat.md).


```python
!pip install /Users/johnmount/Documents/work/pyvtreat/dist/vtreat-0.1.tar.gz
#!pip install https://github.com/WinVector/pyvtreat/raw/master/dist/vtreat-0.1.tar.gz
```

    Processing /Users/johnmount/Documents/work/pyvtreat/dist/vtreat-0.1.tar.gz
    Requirement already satisfied: numpy in /Users/johnmount/anaconda3/envs/aiAcademy/lib/python3.7/site-packages (from vtreat==0.1) (1.16.4)
    Requirement already satisfied: pandas in /Users/johnmount/anaconda3/envs/aiAcademy/lib/python3.7/site-packages (from vtreat==0.1) (0.24.2)
    Requirement already satisfied: statistics in /Users/johnmount/anaconda3/envs/aiAcademy/lib/python3.7/site-packages (from vtreat==0.1) (1.0.3.5)
    Requirement already satisfied: scipy in /Users/johnmount/anaconda3/envs/aiAcademy/lib/python3.7/site-packages (from vtreat==0.1) (1.2.1)
    Requirement already satisfied: python-dateutil>=2.5.0 in /Users/johnmount/anaconda3/envs/aiAcademy/lib/python3.7/site-packages (from pandas->vtreat==0.1) (2.8.0)
    Requirement already satisfied: pytz>=2011k in /Users/johnmount/anaconda3/envs/aiAcademy/lib/python3.7/site-packages (from pandas->vtreat==0.1) (2019.1)
    Requirement already satisfied: docutils>=0.3 in /Users/johnmount/anaconda3/envs/aiAcademy/lib/python3.7/site-packages (from statistics->vtreat==0.1) (0.14)
    Requirement already satisfied: six>=1.5 in /Users/johnmount/anaconda3/envs/aiAcademy/lib/python3.7/site-packages (from python-dateutil>=2.5.0->pandas->vtreat==0.1) (1.12.0)
    Building wheels for collected packages: vtreat
      Building wheel for vtreat (setup.py) ... [?25ldone
    [?25h  Stored in directory: /Users/johnmount/Library/Caches/pip/wheels/28/d1/8a/f8f4ee7c515a6c18d95d64f4d49327fe498b9e6e23d04c7159
    Successfully built vtreat
    Installing collected packages: vtreat
      Found existing installation: vtreat 0.1
        Uninstalling vtreat-0.1:
          Successfully uninstalled vtreat-0.1
    Successfully installed vtreat-0.1


First read in data


```python
import pandas

dir = "../../PracticalDataScienceWithR2nd/PDSwR2/KDD2009/"
d = pandas.read_csv(dir + 'orange_small_train.data.gz', sep='\t', header=0)
vars = [c for c in d.columns]
d.shape
```




    (50000, 230)




```python
churn = pandas.read_csv(dir + 'orange_small_train_churn.labels.txt', header=None)
churn.columns = ["churn"]
churn.shape
```




    (50000, 1)




```python
churn["churn"].value_counts()
```




    -1    46328
     1     3672
    Name: churn, dtype: int64



arrange test/train split


```python
import numpy.random

n = d.shape[0]
is_train = numpy.random.uniform(size=n)<=0.9
is_test = numpy.logical_not(is_train)
```


```python
d_train = d.loc[is_train, :].copy()
churn_train = numpy.asarray(churn.loc[is_train, :]["churn"]==1)
d_test = d.loc[is_test, :].copy()
churn_test = numpy.asarray(churn.loc[is_test, :]["churn"]==1)
```

Treat variables


```python
import vtreat
```


```python
plan = vtreat.binomial_outcome_treatment(outcomename="y", outcometarget=True)
```


```python
cross_frame = plan.fit_transform(d_train, churn_train)
```

    /Users/johnmount/anaconda3/envs/aiAcademy/lib/python3.7/site-packages/pandas/core/indexing.py:1017: FutureWarning: 
    Passing list-likes to .loc or [] with any missing label will raise
    KeyError in the future, you can use .reindex() as an alternative.
    
    See the documentation here:
    https://pandas.pydata.org/pandas-docs/stable/indexing.html#deprecate-loc-reindex-listlike
      return getattr(section, self.name)[new_key]
    /Users/johnmount/anaconda3/envs/aiAcademy/lib/python3.7/site-packages/pandas/core/indexing.py:1494: FutureWarning: 
    Passing list-likes to .loc or [] with any missing label will raise
    KeyError in the future, you can use .reindex() as an alternative.
    
    See the documentation here:
    https://pandas.pydata.org/pandas-docs/stable/indexing.html#deprecate-loc-reindex-listlike
      return self._getitem_tuple(key)



```python
plan.score_frame_
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>variable</th>
      <th>PearsonR</th>
      <th>significance</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Var1_is_bad</td>
      <td>0.003879</td>
      <td>4.105272e-01</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Var2_is_bad</td>
      <td>0.017078</td>
      <td>2.904817e-04</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Var3_is_bad</td>
      <td>0.017045</td>
      <td>2.984289e-04</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Var4_is_bad</td>
      <td>0.018043</td>
      <td>1.288784e-04</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Var5_is_bad</td>
      <td>0.017806</td>
      <td>1.579750e-04</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Var6_is_bad</td>
      <td>-0.031249</td>
      <td>3.318350e-11</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Var7_is_bad</td>
      <td>-0.025575</td>
      <td>5.726515e-08</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Var9_is_bad</td>
      <td>0.003879</td>
      <td>4.105272e-01</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Var10_is_bad</td>
      <td>0.017806</td>
      <td>1.579750e-04</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Var11_is_bad</td>
      <td>0.017045</td>
      <td>2.984289e-04</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Var12_is_bad</td>
      <td>0.003449</td>
      <td>4.642988e-01</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Var13_is_bad</td>
      <td>-0.025575</td>
      <td>5.726515e-08</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Var14_is_bad</td>
      <td>0.017045</td>
      <td>2.984289e-04</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Var16_is_bad</td>
      <td>0.017806</td>
      <td>1.579750e-04</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Var17_is_bad</td>
      <td>0.018043</td>
      <td>1.288784e-04</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Var18_is_bad</td>
      <td>0.018043</td>
      <td>1.288784e-04</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Var19_is_bad</td>
      <td>0.018043</td>
      <td>1.288784e-04</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Var21_is_bad</td>
      <td>-0.031249</td>
      <td>3.318350e-11</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Var22_is_bad</td>
      <td>-0.030976</td>
      <td>4.902507e-11</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Var23_is_bad</td>
      <td>0.017806</td>
      <td>1.579750e-04</td>
    </tr>
    <tr>
      <th>20</th>
      <td>Var24_is_bad</td>
      <td>-0.007340</td>
      <td>1.193836e-01</td>
    </tr>
    <tr>
      <th>21</th>
      <td>Var25_is_bad</td>
      <td>-0.030976</td>
      <td>4.902507e-11</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Var26_is_bad</td>
      <td>0.017806</td>
      <td>1.579750e-04</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Var27_is_bad</td>
      <td>0.017806</td>
      <td>1.579750e-04</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Var28_is_bad</td>
      <td>-0.030994</td>
      <td>4.779534e-11</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Var29_is_bad</td>
      <td>0.003879</td>
      <td>4.105272e-01</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Var30_is_bad</td>
      <td>0.003879</td>
      <td>4.105272e-01</td>
    </tr>
    <tr>
      <th>27</th>
      <td>Var33_is_bad</td>
      <td>0.012544</td>
      <td>7.778937e-03</td>
    </tr>
    <tr>
      <th>28</th>
      <td>Var34_is_bad</td>
      <td>0.017078</td>
      <td>2.904817e-04</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Var35_is_bad</td>
      <td>-0.030976</td>
      <td>4.902507e-11</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>489</th>
      <td>Var224_lev__NA_</td>
      <td>0.007276</td>
      <td>1.226468e-01</td>
    </tr>
    <tr>
      <th>490</th>
      <td>Var225_impact_code</td>
      <td>-0.015174</td>
      <td>1.283765e-03</td>
    </tr>
    <tr>
      <th>491</th>
      <td>Var225_prevalence_code</td>
      <td>0.052299</td>
      <td>1.200583e-28</td>
    </tr>
    <tr>
      <th>492</th>
      <td>Var225_lev__NA_</td>
      <td>0.054166</td>
      <td>1.305157e-30</td>
    </tr>
    <tr>
      <th>493</th>
      <td>Var225_lev_ELof</td>
      <td>-0.044051</td>
      <td>8.693409e-21</td>
    </tr>
    <tr>
      <th>494</th>
      <td>Var225_lev_kG3k</td>
      <td>-0.015436</td>
      <td>1.055461e-03</td>
    </tr>
    <tr>
      <th>495</th>
      <td>Var226_impact_code</td>
      <td>0.000564</td>
      <td>9.047143e-01</td>
    </tr>
    <tr>
      <th>496</th>
      <td>Var226_prevalence_code</td>
      <td>0.020623</td>
      <td>1.208505e-05</td>
    </tr>
    <tr>
      <th>497</th>
      <td>Var226_lev_FSa2</td>
      <td>0.030832</td>
      <td>6.025494e-11</td>
    </tr>
    <tr>
      <th>498</th>
      <td>Var226_lev_Qu4f</td>
      <td>-0.010110</td>
      <td>3.195264e-02</td>
    </tr>
    <tr>
      <th>499</th>
      <td>Var226_lev_WqMG</td>
      <td>-0.001949</td>
      <td>6.792527e-01</td>
    </tr>
    <tr>
      <th>500</th>
      <td>Var226_lev_szEZ</td>
      <td>-0.016404</td>
      <td>5.001684e-04</td>
    </tr>
    <tr>
      <th>501</th>
      <td>Var226_lev_7P5s</td>
      <td>-0.022177</td>
      <td>2.527544e-06</td>
    </tr>
    <tr>
      <th>502</th>
      <td>Var226_lev_fKCe</td>
      <td>0.000871</td>
      <td>8.533186e-01</td>
    </tr>
    <tr>
      <th>503</th>
      <td>Var226_lev_Aoh3</td>
      <td>-0.006621</td>
      <td>1.600614e-01</td>
    </tr>
    <tr>
      <th>504</th>
      <td>Var227_impact_code</td>
      <td>0.005029</td>
      <td>2.859487e-01</td>
    </tr>
    <tr>
      <th>505</th>
      <td>Var227_prevalence_code</td>
      <td>0.049001</td>
      <td>2.408462e-25</td>
    </tr>
    <tr>
      <th>506</th>
      <td>Var227_lev_RAYp</td>
      <td>0.050183</td>
      <td>1.667045e-26</td>
    </tr>
    <tr>
      <th>507</th>
      <td>Var227_lev_ZI9m</td>
      <td>-0.044258</td>
      <td>5.726680e-21</td>
    </tr>
    <tr>
      <th>508</th>
      <td>Var227_lev_6fzt</td>
      <td>-0.005501</td>
      <td>2.431795e-01</td>
    </tr>
    <tr>
      <th>509</th>
      <td>Var228_impact_code</td>
      <td>0.006502</td>
      <td>1.677436e-01</td>
    </tr>
    <tr>
      <th>510</th>
      <td>Var228_prevalence_code</td>
      <td>0.063213</td>
      <td>4.295574e-41</td>
    </tr>
    <tr>
      <th>511</th>
      <td>Var228_lev_F2FyR07IdsN7I</td>
      <td>0.063739</td>
      <td>9.417921e-42</td>
    </tr>
    <tr>
      <th>512</th>
      <td>Var228_lev_55YFVY9</td>
      <td>-0.027750</td>
      <td>3.888481e-09</td>
    </tr>
    <tr>
      <th>513</th>
      <td>Var228_lev_ib5G6X1eUxUn6</td>
      <td>-0.031845</td>
      <td>1.397110e-11</td>
    </tr>
    <tr>
      <th>514</th>
      <td>Var229_impact_code</td>
      <td>-0.018346</td>
      <td>9.907885e-05</td>
    </tr>
    <tr>
      <th>515</th>
      <td>Var229_prevalence_code</td>
      <td>0.060039</td>
      <td>3.116091e-37</td>
    </tr>
    <tr>
      <th>516</th>
      <td>Var229_lev__NA_</td>
      <td>0.060360</td>
      <td>1.296053e-37</td>
    </tr>
    <tr>
      <th>517</th>
      <td>Var229_lev_am7c</td>
      <td>-0.038025</td>
      <td>6.988157e-16</td>
    </tr>
    <tr>
      <th>518</th>
      <td>Var229_lev_mj86</td>
      <td>-0.034782</td>
      <td>1.560654e-13</td>
    </tr>
  </tbody>
</table>
<p>519 rows × 3 columns</p>
</div>




```python
cross_frame.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Var1_is_bad</th>
      <th>Var2_is_bad</th>
      <th>Var3_is_bad</th>
      <th>Var4_is_bad</th>
      <th>Var5_is_bad</th>
      <th>Var6_is_bad</th>
      <th>Var7_is_bad</th>
      <th>Var9_is_bad</th>
      <th>Var10_is_bad</th>
      <th>Var11_is_bad</th>
      <th>...</th>
      <th>Var228_impact_code</th>
      <th>Var228_prevalence_code</th>
      <th>Var228_lev_F2FyR07IdsN7I</th>
      <th>Var228_lev_55YFVY9</th>
      <th>Var228_lev_ib5G6X1eUxUn6</th>
      <th>Var229_impact_code</th>
      <th>Var229_prevalence_code</th>
      <th>Var229_lev__NA_</th>
      <th>Var229_lev_am7c</th>
      <th>Var229_lev_mj86</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>0.002595</td>
      <td>0.654257</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0.000662</td>
      <td>0.568471</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>0.002595</td>
      <td>0.654257</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0.000662</td>
      <td>0.568471</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>0.003815</td>
      <td>0.053311</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>-0.000570</td>
      <td>0.234279</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>0.001937</td>
      <td>0.654257</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>-0.000575</td>
      <td>0.568471</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>0.002453</td>
      <td>0.654257</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>-0.003972</td>
      <td>0.195717</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 519 columns</p>
</div>




```python
import xgboost
```


```python

fd = xgboost.DMatrix(data=cross_frame, label=churn_train)
x_parameters = {"max_depth":3, "objective":'binary:logistic'}
cv = xgboost.cv(x_parameters, fd, num_boost_round=100, verbose_eval=False)
```


```python
cv.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>train-error-mean</th>
      <th>train-error-std</th>
      <th>test-error-mean</th>
      <th>test-error-std</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.073669</td>
      <td>0.000233</td>
      <td>0.073947</td>
      <td>0.000732</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.073769</td>
      <td>0.000260</td>
      <td>0.073836</td>
      <td>0.000577</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.073813</td>
      <td>0.000273</td>
      <td>0.073813</td>
      <td>0.000546</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.073813</td>
      <td>0.000273</td>
      <td>0.073813</td>
      <td>0.000546</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.073813</td>
      <td>0.000273</td>
      <td>0.073813</td>
      <td>0.000546</td>
    </tr>
  </tbody>
</table>
</div>




```python
best = cv.loc[cv["test-error-mean"]<= min(cv["test-error-mean"] + 1.0e-9), :]
best


```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>train-error-mean</th>
      <th>train-error-std</th>
      <th>test-error-mean</th>
      <th>test-error-std</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>64</th>
      <td>0.071192</td>
      <td>0.000063</td>
      <td>0.073347</td>
      <td>0.000258</td>
    </tr>
  </tbody>
</table>
</div>




```python
ntree = best.index.values[0]
ntree
```




    64




```python
fitter = xgboost.XGBClassifier(n_estimators=ntree, max_depth=3, objective='binary:logistic')
fitter
```




    XGBClassifier(base_score=0.5, booster='gbtree', colsample_bylevel=1,
                  colsample_bytree=1, gamma=0, learning_rate=0.1, max_delta_step=0,
                  max_depth=3, min_child_weight=1, missing=None, n_estimators=64,
                  n_jobs=1, nthread=None, objective='binary:logistic',
                  random_state=0, reg_alpha=0, reg_lambda=1, scale_pos_weight=1,
                  seed=None, silent=True, subsample=1)




```python
model = fitter.fit(cross_frame, churn_train)



```


```python
test_processed = plan.transform(d_test)
```


```python

pf = pandas.DataFrame({"churn":churn_test})
preds = model.predict_proba(test_processed)


```


```python
pf["pred"] = preds[:, 1]
```


```python
import wvpy.util
```


```python
wvpy.util.plot_roc(pf["pred"], pf["churn"])
```


![png](output_26_0.png)





    0.7217503377525721




```python

```
